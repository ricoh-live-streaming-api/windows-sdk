// Copyright 2022 RICOH Company, Ltd. All rights reserved.

#pragma once

#define LIVE_STREAMING_MODULE_NAME "LiveStreaming_ClientSDK"
constexpr auto LiveStreaming_ClientSDK = "Live Streaming Client SDK";